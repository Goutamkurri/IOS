//
//  ViewController.swift
//  PlayWithAlphaNumericsApp
//
//  Created by Goutham on 9/13/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var headerLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
            }


}

